<?php
if(isset($_GET["conf_del"])&&!empty($_GET["conf_del"])){

    $id_del = $_POST["id_del"];
    echo    "<script>";
    echo    "Swal.fire({
                title: 'ต้องการลบรายการนี้หรือไม่',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'ยืนยันการลบ',
                cancelButtonText: 'ยกเลิก'
                })";
    echo   "</script>";

}


?>